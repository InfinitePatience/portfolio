import React from 'react'
// import '../styles/Navigation.scss';

function Navigation() {
  return (
  <div>Navigation</div>

  )
}

export default Navigation